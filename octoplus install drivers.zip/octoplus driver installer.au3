#cs ----------------------------------------------------------------------------

	 AutoIt Version: 3.3.18.0
	 Author:         myName

	 Script Function:
		Template AutoIt script.

#ce ----------------------------------------------------------------------------

; Script Start - Add your code below here
; Octoplus / Medusa Box Driver Helper for Win10/11 x64
; Run as Administrator

#include <File.au3> ; for _FileListToArray

; ---------------- CONFIG ----------------
Global Const $g_sDriverFolder = @ScriptDir

; Restrict to specific driver INF names if desired.
; Put Octoplus FTDI / smart-card INF filenames here, or leave array empty and
; change _InfAllowed() to always return True.
Global $g_aInfFilter[2] = ["ftdiport.inf", "ftdibus.inf"] ; adjust for your Octoplus pack

; ---------------- ADMIN CHECK ----------------
If Not IsAdmin() Then
    MsgBox(16, "Octoplus Driver Helper", "Run this script as Administrator.")
    Exit
EndIf

; ---------------- CHECK DRIVER FOLDER ----------------
If Not FileExists($g_sDriverFolder) Then
    MsgBox(16, "Octoplus Driver Helper", "Driver folder not found: " & $g_sDriverFolder)
    Exit
EndIf

; ---------------- SCFILTER CLEANUP ----------------
Func _CleanupSCFILTER()
    Local $sBaseKey = "HKLM\SYSTEM\CurrentControlSet\Enum\SCFILTER"
    Local $sCmd = 'reg query "' & StringReplace($sBaseKey, '"', '\"') & '"'
    Local $sOut = _RunAndGetOutput($sCmd)
    If @error Then Return

    Local $aLines = StringSplit(StringStripCR($sOut), @LF, 1)
    For $i = 1 To $aLines[0]
        Local $sLine = StringStripWS($aLines[$i], 3)
        If StringInStr($sLine, "CID_") Then
            Local $sKey = $sLine
            If StringInStr($sKey, "SCFILTER\CID_") Then
                Local $sRegDel = 'reg delete "' & StringReplace($sKey & "\UpperFilters", '"', '\"') & '" /f'
                _RunAndGetOutput($sRegDel)
            EndIf
        EndIf
    Next
EndFunc

; ---------------- INSTALL .INF DRIVERS (CURRENT FOLDER ONLY) ----------------
Func _InstallInfDrivers($sFolder)
    Local $aFiles = _FileListToArray($sFolder, "*.inf", 1)
    If @error Or Not IsArray($aFiles) Then
        MsgBox(16, "Octoplus Driver Helper", "No .inf files found in: " & $sFolder)
        Return
    EndIf

    For $i = 1 To $aFiles[0]
        Local $sInf = $sFolder & "\" & $aFiles[$i]
        If _InfAllowed($sInf) Then
            Local $sCmd = 'pnputil /add-driver "' & $sInf & '" /install'
            _RunAndGetOutput($sCmd)
        EndIf
    Next
EndFunc

Func _InfAllowed($sInfPath)
    ; If you want to install all INF files in the folder, just: Return True
    Local $sName = StringLower(StringRegExpReplace($sInfPath, "^.*\\", ""))
    For $i = 0 To UBound($g_aInfFilter) - 1
        If StringLower($g_aInfFilter[$i]) = $sName Then Return True
    Next
    Return False
EndFunc

; ---------------- HELPER: RUN AND CAPTURE OUTPUT ----------------
Func _RunAndGetOutput($sCmd)
    Local $iPID = Run(@ComSpec & " /c " & $sCmd, "", @SW_HIDE, BitOR($STDOUT_CHILD, $STDERR_CHILD))
    If $iPID = 0 Then
        SetError(1)
        Return ""
    EndIf
    Local $sData = ""
    While 1
        $sData &= StdoutRead($iPID)
        If @error Then ExitLoop
        Sleep(10)
    WEnd
    Return $sData
EndFunc

; ---------------- MAIN FLOW ----------------
MsgBox(64, "Octoplus Driver Helper", _
    "1) Disable driver signature enforcement for this boot (Win10/11 x64)." & @CRLF & _
    "2) Put Octoplus Box .inf drivers in the same folder as this script." & @CRLF & _
    "3) Disconnect Octoplus/Medusa box, then click OK.")

_InstallInfDrivers($g_sDriverFolder)

MsgBox(64, "Octoplus Driver Helper", _
    "Now plug in the Octoplus/Medusa box, wait 5�10 seconds, then click OK.")

_CleanupSCFILTER()

MsgBox(64, "Octoplus Driver Helper", _
    "Driver install + SCFILTER cleanup completed." & @CRLF & _
    "If software still shows 'smart card not found' or similar, open Octoplus Suite/Medusa updater as admin and update the card if requested.")

Exit